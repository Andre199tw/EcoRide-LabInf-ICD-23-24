#ifndef ECOASCII_H
#define ECOASCII_H
void printlogo();
void printmenu();
void printwelcome();
void caricamento();
void printadmin();
void print1();
#endif