#ifndef SALDO_H
#define SALDO_H
char* searchs(char*);
void modificasaldo(char*,char*);
void registraFeedback(char*);
#endif