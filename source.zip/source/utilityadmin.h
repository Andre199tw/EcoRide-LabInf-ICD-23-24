#ifndef UTILITYADMIN_H
#define UTILITYADMIN_H
void impostaadmin();
void visualizzadmin();
void rimuoviadmin();
void inserisciBici();
void visualizzaBici();
void visualizzaBiciUso();
void disabilita();
void abilita();
void visualizzasegn();
#endif