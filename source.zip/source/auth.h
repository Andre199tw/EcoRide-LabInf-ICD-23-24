#ifndef AUTH_H
#define AUTH_H
int randoma();
void reg();
char* login();
#endif