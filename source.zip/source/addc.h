#ifndef ADD_H
#define ADD_H
void aggiungicarta(char*);
void modifica(char*);
#endif