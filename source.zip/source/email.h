#ifndef EMAIL_H
#define EMAIL_H
void verifica_email(char *, char *, int);
#endif