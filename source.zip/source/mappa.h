#ifndef MAPPA_H
#define MAPPA_H
void aperturamappa();
#endif