#ifndef MENUPAGES_H
#define MENUPAGES_H
void paginaabbonamento(char*);
void paginapagamento(char*);
void pagina_bici(char*);
void paginacarta(char*);
void pbici(char*);
#endif