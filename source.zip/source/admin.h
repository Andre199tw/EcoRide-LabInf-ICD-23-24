#ifndef ADMIN_H
#define ADMIN_H
void gestioneadmin();
void gestionebici();
void gestioneabbonamenti();
void gestionefeedback();
void gestionesegnalazioni();
void gestionestazioni();
void gestionetrans();
#endif